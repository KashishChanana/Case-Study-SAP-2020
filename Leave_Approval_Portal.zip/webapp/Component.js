sap.ui.define(["sap/suite/ui/generic/template/lib/AppComponent"], function (AppComponent) {
	return AppComponent.extend("com.sap.leave_approval_portal.Component", {
		metadata: {
			"manifest": "json"
		}
	});
});